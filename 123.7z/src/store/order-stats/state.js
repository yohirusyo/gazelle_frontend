export default function () {
  return {
    orderStats: [],
    min: null,
    max: null,
  };
}
