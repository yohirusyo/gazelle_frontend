export default function () {
  return {
    contacts: [],
  };
}
