export default function () {
  return {
    customers: [],
    customerPhoneNumber: null,
    customerFullname: null,
    customerSubdivision: null,
  };
}
