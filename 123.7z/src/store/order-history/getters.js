import * as moment from 'moment';

export const getSortedHistory = (state) => () => {
    const newHistory = [];
    for (let index = state.history.length - 1; index >= 0; index--) {
        if (index == state.history.length - 1) {
            newHistory.push({
                ...state.history[index],
                head: true,
            })

        } else {
            newHistory.push({
                ...state.history[index],
                head: !!moment(state.history[index].createdAt).format('YYYYMMDD').localeCompare(moment(state.history[index +1].createdAt).format('YYYYMMDD')),
            })

        }
    }
    return newHistory;
}
