<template>
  <q-virtual-scroll :style="`height: ${height}px`" :items="getSortedHistory()">
    <template v-slot="{ item }">
      <div class="q-mx-lg" v-if="item.head" style="font-size: 1.1rem">
        {{ moment(item.createdAt).lang("ru").format("D MMM, dddd") }}
      </div>
      <BaseCard class="bg-white q-pa-sm column q-my-sm q-mx-sm" radius="md">
        <div class="text-bold q-mx-md">
          {{
            item.orderTime
              ? `Заказ №${item.id}, в ${moment(item.orderTime).format("HH:mm")}`
              : `Заказ №${item.id}, время заказа не назначено`
          }}
        </div>
        <div class="q-mx-md">
          {{
            `${getPlaceById(item.departurePointId)?.name} => ${
              getPlaceById(item.destinationId)?.name
            }`
          }}
        </div>
        <q-separator spaced inset />
        <div
          v-if="
            !item.isApproved &&
            !item.isDeclined &&
            !item.isDone &&
            item.isRequest
          "
          class="text-blue q-mx-md"
        >
          Ожидает подтверждения диспетчера
        </div>
        <div
          v-else-if="
            ((item.isApproved && item.isRequest) || !item.isRequest) &&
            !item.isDone
          "
          class="text-green q-mx-md"
        >
          Заказ выполняется <OrderStatus :orderId="item.id" />
        </div>
        <div
          v-else-if="item.isDeclined && item.isRequest"
          class="text-red q-mx-md"
        >
          Заказ отклонен диспетчером
        </div>
        <div
          v-else-if="item.isDone && !item.isDeleted"
          class="text-grey q-mx-md"
        >
          Заказ выполнен
        </div>
      </BaseCard>
    </template>
  </q-virtual-scroll>
</template>

<script>
import { mapActions, mapGetters } from "vuex";
import OrderStatus from "src/components/order/OrderStatus.vue";
import * as moment from "moment";
import {
  timeFormat,
  formatContact,
  formatCustomerMobileFullname,
  formatCustomerMobileSubdivision,
  formatCustomerMobilePhoneNumber,
  formatPlace,
  formatTransportNumber,
} from "src/helpers/formatters";

import BaseCard from "src/components/base/Card.vue";
export default {
  name: "OrderHistory",
  props: ["col", "height"],
  components: {
    OrderStatus,
    BaseCard,
  },
  computed: {
    ...mapGetters("orderHistory", ["getSortedHistory"]),
    ...mapGetters("place", ["getPlaceById"]),
  },
  data() {
    return {
      height: 0,
    };
  },
  async mounted() {
    await this.requestHistory();
    await this.subscribeHistorySockets();
    this.height =
      (document.getElementsByClassName("q-page")[0]?.clientHeight / 12) *
        this.col -
      41 +
      (this.$q.screen.xs ? 12 : -12);
  },
  methods: {
    ...mapActions("orderHistory", ["requestHistory", "subscribeHistorySockets"]),
    timeFormat,
    formatContact,
    formatCustomerMobileFullname,
    formatCustomerMobileSubdivision,
    formatCustomerMobilePhoneNumber,
    formatPlace,
    formatTransportNumber,
    moment,
  },
};
</script>
