export default function () {
  return {
    places: [],
  };
}
