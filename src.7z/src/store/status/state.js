export default function () {
  return {
    statuses: [],
  };
}
