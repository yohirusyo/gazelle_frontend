
export function set(state, statuses) {
  state.statuses = statuses;
}
