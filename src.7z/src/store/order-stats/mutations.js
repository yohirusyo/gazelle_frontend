export function set(state, orderStats) {
  state.orderStats = orderStats;
}
