export default function () {
  return {
    orderStats: [],
  };
}
