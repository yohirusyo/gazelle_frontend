export default function () {
  return {
    history: [],
  };
}
