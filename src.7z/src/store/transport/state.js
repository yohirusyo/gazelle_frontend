export default function () {
  return {
    transports: [],
  };
}
