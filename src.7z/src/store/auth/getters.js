export function isLoggedIn(state) {
  return !!state.token;
}
