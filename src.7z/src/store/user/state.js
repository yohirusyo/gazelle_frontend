export default function () {
  return {
    drivers: [],
    operators: [],
  };
}
