export default function () {
  return {
    orders: [],
    customerPhoneNumber: null,
    customerFullname: null,
    customerSubdivision: null,
    contactPhoneNumber: null,
    contactFullname: null,
    destinationName: null,
    departurePointName: null,
    name: null,
    names: [],
  };
}
